package Inicio;

import Views.*;
        
public class TrabalhoPoo {

    
    public static void main(String[] args) {
        Controle.ControleInicial.cargaInicial();
        new Login();
    }
    
}
